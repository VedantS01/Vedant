/**
 * Pair.h -- by Vedant -- CS19B074
 * 
 **/


#ifndef PAIR_H
#define PAIR_H

typedef struct Pair {
    int i;
    int j;
} Pair;

#endif