/**
 * ElemType.h -- by Vedant (CS19B074)
 * 
 **/
#ifndef ELEM_TYPE_H
#define ELEM_TYPE_H
typedef long int ElemType;
#endif