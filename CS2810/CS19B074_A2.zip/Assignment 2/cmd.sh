g++ -o solution main.cpp Matrix.cpp MatrixMedian.cpp
./solution < input.txt > output.txt