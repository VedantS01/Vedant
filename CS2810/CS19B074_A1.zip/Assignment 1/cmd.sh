g++ -o solution main.cpp Matrix.cpp
./solution < input.txt > output.txt