g++ -o solution main.cpp Graph.cpp Stack.cpp
./solution < input.txt > output.txt