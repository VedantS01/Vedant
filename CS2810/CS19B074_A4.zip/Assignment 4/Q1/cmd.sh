g++ -o solution main.cpp
./solution < input.txt > output.txt